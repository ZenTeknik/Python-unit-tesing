from basicmath import div


def test_div():
  assert div(4,2) == 2

def test_div2():
     assert div(6,2) == 3



def  test_for_float():
    assert div(1,2) == 2

# #Here is  the flase case that  give zero division error 
#  def  test_for_float2():
#     assert div(2,0) == 0 