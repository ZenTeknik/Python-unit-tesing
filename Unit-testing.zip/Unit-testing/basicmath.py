

def div(a,b):
    return a/b

print(div(12,4))

